import java.util.Scanner;

public class Student {

    private final int id;
     String fullName;
     String address;
     int age;
     int grade;
     int[] marks = new int[5];
     int minMark;
     int maxMark;
     int averageMark;

    public Student() {
        this.id = (int) (Math.random() * 1000);
    }

    public void Enterinfo () {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Your full name: ");
        this.fullName = scanner.nextLine();

        System.out.println("Enter Your address: ");
        this.address = scanner.nextLine();

        System.out.println("Enter Your age: ");
        this.age = scanner.nextInt();

        System.out.println("Enter Your grade: ");
        this.grade = scanner.nextInt();

        for (int i = 0; i < 5; i++) {
            System.out.println("Enter Your mark for subject " + (i + 1) + ": ");
            this.marks[i] = scanner.nextInt();
        }
    }

    public void AverageMark() {
        int averageMark = 0;
        for (int mark : this.marks) {
            averageMark += mark;
        }
        averageMark /= this.marks.length;

        this.averageMark = averageMark;
    }

    public void findMaxAndMinMarks() {
        int maxMark = this.marks[0];
        int minMark = this.marks[0];

        for (int mark : this.marks) {
            if (mark > maxMark) {
                maxMark = mark;
            }
            if (mark < minMark) {
                minMark = mark;
            }
        }

        this.maxMark = maxMark;
        this.minMark = minMark;
    }

    public void displayInfo() {
        System.out.println("----------------------------------------------------------------------------------");
        System.out.println("| ID | Full Name | Age | Address | Grade | Average Mark | Max | Min |");
        System.out.println("----------------------------------------------------------------------------------");
        System.out.println("| " + this.id + " | " + this.fullName + " | " + this.age + " | " + this.address + " | " + this.grade + " | " + this.averageMark + " | " + this.maxMark + " | " + this.minMark + " |");
        System.out.println("----------------------------------------------------------------------------------");
    }}